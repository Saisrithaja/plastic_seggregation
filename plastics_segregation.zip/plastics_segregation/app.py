from flask import Flask, render_template, request
import os
import time
from ultralytics import YOLO
import shutil

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        filename = file.filename
        file_path = f"uploads/{filename}"
        file.save(file_path)

        start_time = time.time()
        model = YOLO("/Users/saisrithaja/Desktop/plastics_segregation/best.pt")
        results = model.predict(source=file_path, imgsz=640, conf=0.5, show=True, save=True)
        save_dir = results[0].save_dir
        # Concatenate the image name with the save_dir path
        save_dir_with_image = os.path.join(save_dir, filename)
        
        output_folder = '/Users/saisrithaja/Desktop/plastics_segregation/static/output'
        os.makedirs(output_folder, exist_ok=True)
        # Copy the image to the output folder
        output_image_path = os.path.join(output_folder, filename)
        shutil.copyfile(save_dir_with_image, output_image_path)
        end_time = time.time()
        execution_time = end_time - start_time
        print("Execution Time:", execution_time, "seconds")

        return render_template('index.html', output_image_path=output_image_path,filename=filename)

if __name__ == '__main__':
    app.run(debug=True)
